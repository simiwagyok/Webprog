var negyzet=document.getElementById("negyzet");

function torles() {
    if(confirm('Tényleg ki szeretnéd törölni?')){
        document.getElementById("vizszintes").value = 0
        document.getElementById("fuggoleges").value = 0
        document.getElementById("forgatas").value = 0
        document.getElementById("meretezes").value = 0
        document.getElementById("ferdites").value = 0
        negyzet.style.transform = '';
    }
}
function szerkesztes(){
    var vizszintes = document.getElementById("vizszintes").value
    var fuggoleges = document.getElementById("fuggoleges").value
    var forgatas = document.getElementById("forgatas").value
    var meretezes = document.getElementById("meretezes").value
    var ferdites = document.getElementById("ferdites").value
    negyzet.style.transform=`translateX(${vizszintes}px) translateY(${fuggoleges}px) rotate(${forgatas}deg) scale(${1 + meretezes * 1}) skewX(${ferdites}deg)`
}