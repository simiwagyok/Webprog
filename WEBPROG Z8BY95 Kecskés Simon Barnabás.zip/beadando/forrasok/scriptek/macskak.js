window.onload = function() {

    getData();
}

function getData() {

    var filternev = document.getElementById("nev").value.trim();
    var szarmazas = document.getElementById("honnan").value.trim();


    var url = "http://127.0.0.1:3000/cats";

    if (filternev != "") {
        url += "?name=" + filternev;
    }
    if (szarmazas != "") {
        url += (url.includes('?') ? '&' : '?') + "origin=" + szarmazas;
    }


    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var data = JSON.parse(this.responseText);
            outputData(data);  
        }
    };


    xhttp.open("GET", url, true);
    xhttp.send();
}

function outputData(data) {
    var tablazat = document.getElementById("tablazat");
    tablazat.innerHTML = "";  

 
    for (var i = 0; i < data.length; i++) {
        var element = data[i];
        tablazat.innerHTML += `
            <tr>
                <td>${element.id}</td>
                <td>${element.name}</td>
                <td>${element.origin}</td>
                <td>${element.length}</td>
                <td><button onclick="delet(${element.id})">X</button></td>
            </tr>
        `;
    }
}

function delet(id) {
 
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            getData();  
        }
    };


    xhttp.open("DELETE", "http://127.0.0.1:3000/cats/" + id, true);
    xhttp.send();
}
