const todoInput = document.getElementById("todoBe");
const addButton = document.getElementById("gombAdd");
const szamlalo = document.getElementById("todoSzamol");
const todoList = document.getElementById("todoLista");

let maradek = 0;


function updateCounter() {
    szamlalo.textContent = `Jelenleg ${maradek} db befejezetlen teendőd van.`;
}


function createTodoItem(todoText) {
    const listItem = document.createElement("li");

    const textSpan = document.createElement("span");
    textSpan.textContent = todoText;

    const doneButton = createButton("✓", "done", () => markAsDone(listItem));
    const deleteButton = createButton("⨉", "delete", () => deleteTodoItem(listItem));

    listItem.appendChild(textSpan);
    listItem.appendChild(deleteButton);
    listItem.appendChild(doneButton);

    return listItem;
}


function createButton(label, className, onClick) {
    const button = document.createElement("button");
    button.textContent = label;
    button.className = className;
    button.addEventListener("click", onClick);
    return button;
}


function addTodo() {
    const todoText = todoInput.value.trim();

    if (todoText === "") {
        alert("Nem lehet üres a teendő szövege!");
        return;
    }

    const newTodo = createTodoItem(todoText);
    todoList.appendChild(newTodo);

    todoInput.value = "";
    maradek++;
    updateCounter();
}


function markAsDone(listItem) {
    if (!listItem.classList.contains("done")) {
        listItem.classList.add("done");
        const deleteButton = listItem.querySelector(".delete");
        if (deleteButton) deleteButton.remove();
        maradek--;
        updateCounter();
    }
}


function deleteTodoItem(listItem) {
    if (!listItem.classList.contains("done")) {
        maradek--;
    }
    todoList.removeChild(listItem);
    updateCounter();
}


addButton.addEventListener("click", addTodo);
